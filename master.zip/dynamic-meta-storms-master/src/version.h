// Updated at Oct 14, 2019
// Bioinformatics Group, Single-Cell Research Center, QIBEBT, CAS
// Code by: Honglei Wang, Gongchao Jing, Xiaoquan Su
// Define the version of Parallel-META toolkit

#ifndef _VERSION_H
#define _VERSION_H

#define Version "1.1"

#endif
