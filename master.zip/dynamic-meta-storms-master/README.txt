#Dynamic-MetaStorms quick installation
  source install.sh

#An example dataset is provided in “example” folder, see “example/Readme” for more details.
